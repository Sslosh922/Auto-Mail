import pandas as pd
import requests
import streamlit as st
from serpapi import GoogleSearch
import gspread
from gspread_dataframe import set_with_dataframe
from dotenv import load_dotenv
import os
import time
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
import schedule
import threading
import re
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime, timedelta
import uuid
import sqlite3
from pathlib import Path
import base64
from urllib.parse import quote

# Load environment variables
load_dotenv()

# API Keys
SERP_API_KEY = os.getenv("SERP_API_KEY")
GROQ_API_KEY = os.getenv("GROQ_API_KEY")
SERVICE_ACCOUNT_FILE = "C:\\Users\\acer\\bai\\Info-Miner\\Credentials.json"
EMAIL = os.getenv("EMAIL")
MAILJET_API_KEY = os.getenv("MAILJET_API_KEY")
MAILJET_SECRET_KEY = os.getenv("MAILJET_SECRET_KEY")

# Database setup for email tracking
def init_database():
    """Initialize SQLite database for email tracking"""
    db_path = Path("email_tracking.db")
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS email_logs (
            id TEXT PRIMARY KEY,
            recipient_email TEXT,
            company_name TEXT,
            subject TEXT,
            sent_time TIMESTAMP,
            status TEXT,
            delivery_status TEXT,
            opened BOOLEAN DEFAULT FALSE,
            clicked BOOLEAN DEFAULT FALSE,
            bounced BOOLEAN DEFAULT FALSE,
            spam_score REAL,
            error_message TEXT
        )
    ''')
    
    conn.commit()
    conn.close()

def log_email_status(email_id, recipient_email, company_name, subject, status, delivery_status="pending", error_message=None):
    """Log email status to database"""
    conn = sqlite3.connect("email_tracking.db")
    cursor = conn.cursor()
    
    cursor.execute('''
        INSERT OR REPLACE INTO email_logs 
        (id, recipient_email, company_name, subject, sent_time, status, delivery_status, error_message)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    ''', (email_id, recipient_email, company_name, subject, datetime.now(), status, delivery_status, error_message))
    
    conn.commit()
    conn.close()

def get_email_stats():
    """Get email statistics from database"""
    conn = sqlite3.connect("email_tracking.db")
    df = pd.read_sql_query("SELECT * FROM email_logs ORDER BY sent_time DESC", conn)
    conn.close()
    return df

# Email validation function (enhanced)
def is_valid_email(email):
    """Enhanced email validation"""
    if not email or pd.isna(email):
        return False
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return re.match(pattern, str(email)) is not None

def validate_email_deliverability(email):
    """Check email deliverability factors"""
    score = 100
    warnings = []
    
    # Check for disposable email domains
    disposable_domains = ['temp-mail.org', '10minutemail.com', 'guerrillamail.com', 'mailinator.com']
    if any(domain in email.lower() for domain in disposable_domains):
        score -= 30
        warnings.append("Disposable email domain")
    
    # Check for common personal domains vs business domains
    personal_domains = ['gmail.com', 'yahoo.com', 'hotmail.com', 'outlook.com']
    if any(domain in email.lower() for domain in personal_domains):
        score -= 10
        warnings.append("Personal email domain - may have stricter spam filters")
    
    return score, warnings

# Enhanced Google Sheets functions (keeping original functionality)
def authenticate_google_sheets():
    try:
        client = gspread.service_account(filename=SERVICE_ACCOUNT_FILE)
        return client
    except Exception as e:
        st.error(f"Authentication Error: {str(e)}")
        return None

def load_google_sheet(sheet_url):
    try:
        gc = authenticate_google_sheets()
        if gc is None:
            return None, None, None
        sheet_key = sheet_url.split('/d/')[1].split('/')[0]
        sheet = gc.open_by_key(sheet_key)
        worksheet = sheet.get_worksheet(0)
        data = worksheet.get_all_records()
        return pd.DataFrame(data), gc, worksheet
    except Exception as e:
        st.error(f"Error loading sheet: {str(e)}")
        return None, None, None

def update_google_sheet(worksheet, results_df):
    try:
        data = [results_df.columns.values.tolist()]
        data.extend(results_df.values.tolist())
        worksheet.clear()
        worksheet.update('A1', data)
        return True, "Google Sheet updated successfully!"
    except Exception as e:
        detailed_error = f"Error updating sheet: {str(e)}"
        st.error(detailed_error)
        return False, detailed_error

# Enhanced search and AI functions (keeping original functionality)
def get_search_results(query, prompt, api_key, column_name):
    try:
        search_query = prompt.format(column_name=query)
    except KeyError:
        search_query = prompt.replace("{col_name}", query).replace("{column_name}", query)

    params = {
        "engine": "google",
        "q": search_query,
        "num": 100,
        "api_key": api_key
    }

    search = GoogleSearch(params)
    results = search.get_dict()

    text_content = ""
    if "knowledge_graph" in results:
        knowledge = results["knowledge_graph"]
        for key in ["title", "type", "website", "founded", "headquarters", "revenue",
                    "social", "mobile", "phone", "ceo", "email", "contact email",
                    "address", "contact", "call", "chat", "connect", "write",
                    "twitter", "instagram", "facebook"]:
            text_content += f"{knowledge.get(key, '')}\n"

    for result in results.get("organic_results", []):
        text_content += f"{result.get('title', 'N/A')} - {result.get('snippet', 'N/A')}\n"

    return text_content

def ask_groq_api(question, company, context, api_key):
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json"
    }
    prompt = f"""
    You are an AI assistant specialized in extracting specific information from any data.
    From the context and question provided, extract only the feature which is asked in the question.
    Respond only with the asked feature, without any verbosity. Clean and exact answers only.

    Question: {question}
    Company: {company}
    Context: {context}
    """
    payload = {
        "model": "llama3-8b-8192",
        "messages": [
            {"role": "system", "content": "You are an assistant that extracts specific information from context."},
            {"role": "user", "content": prompt}
        ]
    }
    wait_time = 30
    max_retries = 5

    for attempt in range(max_retries):
        try:
            response = requests.post("https://api.groq.com/openai/v1/chat/completions", headers=headers, json=payload)
            if response.status_code == 200:
                response_json = response.json()
                return response_json['choices'][0]['message']['content'].strip()
            elif response.status_code == 429:
                print(f"Rate limit reached. Waiting for {wait_time} seconds before retrying...")
                time.sleep(wait_time)
                wait_time *= 2
            else:
                return f"Error: {response.status_code}, {response.text}"
        except Exception as e:
            return f"Error: {str(e)}"
    return "Error: Max retries exceeded. Please try again later."

def generate_email_content(template, company_name, company_info, extracted_info, api_key):
    """Generate personalized email content using Llama model"""
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json"
    }
    
    # Enhanced prompt for better deliverability
    prompt = f"""
    You are an expert email writer specializing in business communications that avoid spam filters.
    Generate a professional, personalized email that follows these deliverability best practices:

    Template/Instructions: {template}
    
    Company Name: {company_name}
    Company Information: {company_info}
    Additional Details: {extracted_info}
    
    IMPORTANT DELIVERABILITY RULES:
    1. Use professional, conversational tone (not overly salesy)
    2. Avoid spam trigger words like "FREE", "URGENT", "GUARANTEED", excessive exclamation marks
    3. Include specific, relevant details about the company
    4. Make it sound like genuine business correspondence
    5. Keep subject line under 50 characters
    6. Use proper sentence structure and grammar
    7. Include a clear but subtle call-to-action
    8. Personalize with specific company details
    
    Generate only the email content without any additional text or explanations.
    """
    
    payload = {
        "model": "llama3-8b-8192",
        "messages": [
            {"role": "system", "content": "You are a professional email writer who creates personalized, spam-filter-friendly business emails."},
            {"role": "user", "content": prompt}
        ],
        "temperature": 0.7,
        "max_tokens": 1000
    }
    
    wait_time = 30
    max_retries = 3
    
    for attempt in range(max_retries):
        try:
            response = requests.post("https://api.groq.com/openai/v1/chat/completions", headers=headers, json=payload)
            if response.status_code == 200:
                response_json = response.json()
                generated_content = response_json['choices'][0]['message']['content'].strip()
                return generated_content
            elif response.status_code == 429:
                print(f"Rate limit reached. Waiting for {wait_time} seconds before retrying...")
                time.sleep(wait_time)
                wait_time *= 2
            else:
                return f"Error generating content: {response.status_code}, {response.text}"
        except Exception as e:
            return f"Error generating content: {str(e)}"
    
    return "Error: Could not generate email content. Please try again later."

def generate_email_subject(template, company_name, company_info, api_key):
    """Generate personalized email subject using Llama model with spam-filter awareness"""
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json"
    }

    prompt = f"""
    Generate a professional email subject line that will pass spam filters.

    Template/Instructions: {template}
    Company Name: {company_name}
    Company Information: {company_info}

    DELIVERABILITY RULES:
    1. Keep under 50 characters
    2. Avoid ALL CAPS, excessive punctuation (!!!), and spam words
    3. Make it specific and personalized
    4. Sound like genuine business correspondence
    5. Include company name naturally
    6. Avoid words like: FREE, URGENT, GUARANTEED, AMAZING, INCREDIBLE
    7. Use title case or sentence case
    8. Do not include any newline characters

    Generate only the subject line without any additional text.
    """

    payload = {
        "model": "llama3-8b-8192",
        "messages": [
            {"role": "system", "content": "You are an expert at creating professional, spam-filter-friendly email subject lines without newlines."},
            {"role": "user", "content": prompt}
        ],
        "temperature": 0.7,
        "max_tokens": 100
    }

    try:
        response = requests.post("https://api.groq.com/openai/v1/chat/completions", headers=headers, json=payload)
        if response.status_code == 200:
            response_json = response.json()
            # Remove any newlines from the generated subject
            return response_json['choices'][0]['message']['content'].strip().replace('\n', '')
        else:
            return template.replace("{company_name}", company_name)
    except Exception as e:
        return template.replace("{company_name}", company_name)

def authenticate_and_update(sheet_url, df2):
    gc2 = gspread.service_account(filename=SERVICE_ACCOUNT_FILE)
    spreadsheet = gc2.open_by_url(sheet_url)
    worksheet = spreadsheet.sheet1
    set_with_dataframe(worksheet, df2)
    st.success("Data uploaded successfully!")

def create_html_email_body(plain_text, company_name, tracking_id=None):
    """Create HTML email body with better formatting and optional tracking"""
    
    # Add tracking pixel if tracking_id is provided
    tracking_pixel = f'<img src="https://your-tracking-domain.com/pixel/{tracking_id}" width="1" height="1" style="display:none;">' if tracking_id else ""
    
    html_body = f"""
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Email from AutoMail</title>
    </head>
    <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;">
        <div style="background-color: #f8f9fa; padding: 20px; border-radius: 10px; margin-bottom: 20px;">
            <div style="background-color: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1);">
                <div style="white-space: pre-line; margin-bottom: 20px;">
                    {plain_text}
                </div>
                
                <hr style="border: none; height: 1px; background-color: #e9ecef; margin: 20px 0;">
                
                <div style="font-size: 12px; color: #6c757d; text-align: center;">
                    <p>This email was sent by AutoMail Email System</p>
                    <p>If you'd like to unsubscribe, please reply with "UNSUBSCRIBE" in the subject line.</p>
                </div>
            </div>
        </div>
        {tracking_pixel}
    </body>
    </html>
    """
    return html_body

# Inside the send_email_enhanced function
def send_email_enhanced(receiver_email, subject, body, company_name="Unknown Company"):
    """Enhanced email sending with better deliverability practices"""

    email_id = str(uuid.uuid4())

    # Validate email
    if not is_valid_email(receiver_email):
        log_email_status(email_id, receiver_email, company_name, subject, "failed", "invalid_email", "Invalid email address")
        return False, f"Invalid email address: {receiver_email}", email_id

    # Check deliverability score
    deliverability_score, warnings = validate_email_deliverability(receiver_email)

    # Check if required environment variables are set
    if not EMAIL or not MAILJET_API_KEY or not MAILJET_SECRET_KEY:
        error_msg = "Missing email configuration. Check environment variables."
        log_email_status(email_id, receiver_email, company_name, subject, "failed", "config_error", error_msg)
        return False, error_msg, email_id

    sender_email = EMAIL
    sender_name = "BreakoutAI Team"

    # Create multipart message with both plain text and HTML
    msg = MIMEMultipart('alternative')
    msg['From'] = f"{sender_name} <{sender_email}>"
    msg['To'] = receiver_email

    # Ensure subject line doesn't contain newlines
    clean_subject = subject.replace('\n', '') if subject else "Partnership Opportunity for Test Company"
    msg['Subject'] = clean_subject

    # Add custom headers to improve deliverability
    msg['Reply-To'] = sender_email
    msg['Return-Path'] = sender_email
    msg['X-Mailer'] = 'BreakoutAI Email System v2.0'
    msg['X-Priority'] = '3'
    msg['Message-ID'] = f"<{email_id}@breakoutai.com>"

    # Ensure body is not None
    email_body = body if body else "Thank you for your time."

    # Create plain text and HTML versions
    text_part = MIMEText(email_body, 'plain', 'utf-8')
    html_part = MIMEText(create_html_email_body(email_body, company_name, email_id), 'html', 'utf-8')

    # Attach parts
    msg.attach(text_part)
    msg.attach(html_part)

    try:
        # Create SMTP connection with enhanced settings
        server = smtplib.SMTP('in-v3.mailjet.com', 587)
        server.starttls()
        
        # Login with Mailjet credentials
        server.login(MAILJET_API_KEY, MAILJET_SECRET_KEY)
        
        # Send email
        text = msg.as_string()
        server.sendmail(sender_email, receiver_email, text)
        server.quit()
        
        # Log successful send
        delivery_status = "primary" if deliverability_score > 80 else "likely_spam" if deliverability_score < 50 else "secondary"
        log_email_status(email_id, receiver_email, company_name, clean_subject, "sent", delivery_status)
        
        return True, f"Email sent successfully to {receiver_email} (Deliverability Score: {deliverability_score}%)", email_id
        
    except Exception as e:
        error_msg = f"Error sending email: {str(e)}"
        log_email_status(email_id, receiver_email, company_name, clean_subject, "failed", "unknown_error", error_msg)
        return False, error_msg, email_id
def create_email_dashboard():
    """Create comprehensive email dashboard"""
    st.header("📊 Email Campaign Dashboard")
    
    # Get email statistics
    email_stats = get_email_stats()
    
    if email_stats.empty:
        st.info("No email data available yet. Send some emails to see statistics!")
        return
    
    # Summary metrics
    col1, col2, col3, col4 = st.columns(4)
    
    total_emails = len(email_stats)
    sent_emails = len(email_stats[email_stats['status'] == 'sent'])
    failed_emails = len(email_stats[email_stats['status'] == 'failed'])
    primary_emails = len(email_stats[email_stats['delivery_status'] == 'primary'])
    
    with col1:
        st.metric("Total Emails", total_emails)
    with col2:
        st.metric("Successfully Sent", sent_emails, delta=f"{(sent_emails/total_emails)*100:.1f}%" if total_emails > 0 else "0%")
    with col3:
        st.metric("Failed", failed_emails, delta=f"-{(failed_emails/total_emails)*100:.1f}%" if total_emails > 0 else "0%")
    with col4:
        st.metric("Primary Inbox", primary_emails, delta=f"{(primary_emails/sent_emails)*100:.1f}%" if sent_emails > 0 else "0%")
    
    # Charts
    col1, col2 = st.columns(2)
    
    with col1:
        # Email Status Distribution
        status_counts = email_stats['status'].value_counts()
        fig_status = px.pie(
            values=status_counts.values, 
            names=status_counts.index, 
            title="Email Status Distribution",
            color_discrete_map={'sent': '#28a745', 'failed': '#dc3545'}
        )
        st.plotly_chart(fig_status, use_container_width=True)
    
    with col2:
        # Delivery Status Distribution (for sent emails only)
        sent_only = email_stats[email_stats['status'] == 'sent']
        if not sent_only.empty:
            delivery_counts = sent_only['delivery_status'].value_counts()
            fig_delivery = px.pie(
                values=delivery_counts.values, 
                names=delivery_counts.index, 
                title="Delivery Status (Sent Emails)",
                color_discrete_map={
                    'primary': '#28a745', 
                    'secondary': '#ffc107', 
                    'likely_spam': '#dc3545'
                }
            )
            st.plotly_chart(fig_delivery, use_container_width=True)
    
    # Timeline chart
    if 'sent_time' in email_stats.columns:
        email_stats['sent_time'] = pd.to_datetime(email_stats['sent_time'])
        daily_stats = email_stats.groupby([email_stats['sent_time'].dt.date, 'status']).size().unstack(fill_value=0)
        
        fig_timeline = go.Figure()
        
        if 'sent' in daily_stats.columns:
            fig_timeline.add_trace(go.Scatter(
                x=daily_stats.index, 
                y=daily_stats['sent'], 
                mode='lines+markers',
                name='Sent',
                line=dict(color='#28a745')
            ))
        
        if 'failed' in daily_stats.columns:
            fig_timeline.add_trace(go.Scatter(
                x=daily_stats.index, 
                y=daily_stats['failed'], 
                mode='lines+markers',
                name='Failed',
                line=dict(color='#dc3545')
            ))
        
        fig_timeline.update_layout(
            title="Email Sending Timeline",
            xaxis_title="Date",
            yaxis_title="Number of Emails",
            hovermode='x unified'
        )
        
        st.plotly_chart(fig_timeline, use_container_width=True)
    
    # Recent emails table
    st.subheader("📋 Recent Emails")
    
    # Display recent emails with status
    recent_emails = email_stats.head(20)
    if not recent_emails.empty:
        # Format the dataframe for better display
        display_df = recent_emails[['company_name', 'recipient_email', 'subject', 'status', 'delivery_status', 'sent_time']].copy()
        display_df['sent_time'] = pd.to_datetime(display_df['sent_time']).dt.strftime('%Y-%m-%d %H:%M')
        
        # Add status icons
        status_icons = {'sent': '✅', 'failed': '❌'}
        delivery_icons = {'primary': '🎯', 'secondary': '📂', 'likely_spam': '⚠️', 'pending': '⏳'}
        
        display_df['Status'] = display_df['status'].map(status_icons) + ' ' + display_df['status'].str.title()
        display_df['Delivery'] = display_df['delivery_status'].map(delivery_icons) + ' ' + display_df['delivery_status'].str.replace('_', ' ').str.title()
        
        st.dataframe(
            display_df[['company_name', 'recipient_email', 'subject', 'Status', 'Delivery', 'sent_time']],
            column_config={
                "company_name": "Company",
                "recipient_email": "Email",
                "subject": "Subject",
                "sent_time": "Sent Time"
            },
            use_container_width=True
        )
    
    # Export functionality
    st.subheader("📥 Export Data")
    col1, col2 = st.columns(2)
    
    with col1:
        csv = email_stats.to_csv(index=False)
        st.download_button(
            label="📊 Download Email Stats CSV",
            data=csv,
            file_name=f"email_stats_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
            mime="text/csv"
        )
    
    with col2:
        if st.button("🔄 Refresh Dashboard"):
            st.experimental_rerun()

# Initialize database on app start
init_database()

# --- Streamlit App UI ---
st.title("🚀 AutoMail : An Enhanced Email System")

# Sidebar navigation
st.sidebar.title("Navigation")
page = st.sidebar.selectbox("Choose a page", ["Email Campaign", "Dashboard", "Settings"])

if page == "Email Campaign":
    # Initialize session state
    if 'update_triggered' not in st.session_state:
        st.session_state.update_triggered = False
    if 'results_df' not in st.session_state:
        st.session_state.results_df = None

    # Check environment variables
    st.sidebar.header("Configuration Status")
    env_vars = {
        "SERP_API_KEY": SERP_API_KEY,
        "GROQ_API_KEY": GROQ_API_KEY,
        "EMAIL": EMAIL,
        "MAILJET_API_KEY": MAILJET_API_KEY,
        "MAILJET_SECRET_KEY": MAILJET_SECRET_KEY
    }

    for var_name, var_value in env_vars.items():
        if var_value:
            st.sidebar.success(f"✓ {var_name}")
        else:
            st.sidebar.error(f"✗ {var_name} - Missing")

    upload_choice = st.radio("Load the data:", ["Upload CSV File", "Enter Google Sheet URL"], key="upload_radio")
    df, gc, worksheet = None, None, None

    if upload_choice == "Upload CSV File":
        uploaded_file = st.file_uploader("Choose a CSV file", type=["csv"])
        if uploaded_file:
            df = pd.read_csv(uploaded_file)
            st.write("Data Preview:", df)

    elif upload_choice == "Enter Google Sheet URL":
        sheet_url = st.text_input("Enter the Google Sheet URL")
        if sheet_url:
            df, gc, worksheet = load_google_sheet(sheet_url)
            if df is not None:
                st.write("Data Preview:", df)

    if df is not None:
        col_list = list(df.columns)
        col_list.insert(0, "Select")
        column_name = st.selectbox("Select the column to search in", col_list)

        if column_name != "Select":
            custom_prompt = st.text_input("Enter your custom prompt (use {column_name} as placeholder):")

            if st.button("Search and Extract") and custom_prompt:
                with st.spinner("Processing..."):
                    data_collect = []
                    progress_bar = st.progress(0)
                    total_items = len(df[column_name])

                    for idx, entity in enumerate(df[column_name]):
                        try:
                            search_results = get_search_results(entity, custom_prompt, SERP_API_KEY, column_name)
                            extracted_info = ask_groq_api(custom_prompt, entity, search_results, GROQ_API_KEY)
                            email = ask_groq_api("Extract company Gmail address", entity, search_results, GROQ_API_KEY)
                            time.sleep(30)
                            data_collect.append({
                                column_name: entity,
                                "Extracted Information": extracted_info,
                                "Gmail": email if "gmail.com" in email else "Not found"
                            })
                        except Exception as e:
                            data_collect.append({
                                column_name: entity,
                                "Extracted Information": f"Extraction error: {str(e)}",
                                "Gmail": "Not found"
                            })
                        progress_bar.progress((idx + 1) / total_items)

                    results_df = pd.DataFrame(data_collect)
                    st.session_state.results_df = results_df
                    st.session_state['df2'] = results_df
                    st.write("Extracted Results:", results_df)

                    csv = results_df.to_csv(index=False)
                    st.download_button("Download Results", csv, "extracted_results.csv", "text/csv")

            permit_update = st.selectbox("Update sheet or not ", ["select", "yes", "no"])
            if permit_update.lower() == "yes":
                st.write("Updating Google Sheet...")
                authenticate_and_update(sheet_url, st.session_state['df2'])

            # Enhanced Email section
            if st.session_state.results_df is not None:
                st.header("🚀 AI-Powered Email Campaign")
                
                # Show email statistics with deliverability insights
                valid_emails = st.session_state.results_df['Gmail'].apply(is_valid_email).sum()
                total_emails = len(st.session_state.results_df)
                
                # Calculate deliverability scores for all emails
                deliverability_scores = []
                for email in st.session_state.results_df['Gmail']:
                    if is_valid_email(email):
                        score, warnings = validate_email_deliverability(email)
                        deliverability_scores.append(score)
                
                avg_deliverability = sum(deliverability_scores) / len(deliverability_scores) if deliverability_scores else 0
                
                col1, col2, col3 = st.columns(3)
                with col1:
                    st.metric("Valid Emails", f"{valid_emails}/{total_emails}")
                with col2:
                    st.metric("Avg Deliverability Score", f"{avg_deliverability:.1f}%")
                with col3:
                    primary_likely = len([s for s in deliverability_scores if s > 80])
                    st.metric("Likely Primary Inbox", f"{primary_likely}/{valid_emails}")
                
                # Deliverability tips
                if avg_deliverability < 70:
                    st.warning("⚠️ **Deliverability Alert**: Many emails may go to spam. Consider:")
                    st.markdown("""
                    - Using more business email addresses (avoid @gmail.com for business outreach)
                    - Personalizing content further
                    - Testing with smaller batches first
                    - Setting up email authentication (SPF, DKIM, DMARC)
                    """)
                elif avg_deliverability > 80:
                    st.success("✅ **Good Deliverability**: Most emails should reach primary inbox!")
                
                # AI Generation Toggle
                use_ai_generation = st.checkbox("Use AI to generate personalized email content", value=True)
                
                if use_ai_generation:
                    st.info("🤖 AI will generate personalized, spam-filter-friendly content")
                    subject_template = st.text_input(
                        "Enter email subject template/prompt:", 
                        placeholder="e.g., 'Create a professional subject line for a partnership proposal to {company_name}. Keep it under 50 characters and avoid spam words.'"
                    )
                    body_template = st.text_area(
                        "Enter email body template/prompt:", 
                        placeholder="e.g., 'Write a professional email proposing a partnership with {company_name}. Mention their recent achievements and explain how our services can benefit them. Keep it conversational and avoid salesy language.'",
                        height=150
                    )
                else:
                    st.info("📝 Standard template mode - use {company_name} as placeholder")
                    subject_template = st.text_input(
                        "Enter email subject template:", 
                        placeholder="e.g., 'Partnership Opportunity with {company_name}'"
                    )
                    body_template = st.text_area(
                        "Enter email body template:", 
                        placeholder="e.g., 'Dear {company_name} team,\n\nI hope this email finds you well...'",
                        height=150
                    )
                
                # Email timing options
                st.subheader("📅 Email Timing")
                email_timing = st.selectbox(
                    "Choose sending option:",
                    ["Send immediately", "Schedule for later", "Send in batches"]
                )
                
                batch_size = 10
                batch_delay = 300  # 5 minutes
                
                if email_timing == "Send in batches":
                    col1, col2 = st.columns(2)
                    with col1:
                        batch_size = st.number_input("Emails per batch", min_value=1, max_value=50, value=10)
                    with col2:
                        batch_delay = st.number_input("Delay between batches (minutes)", min_value=1, max_value=1440, value=5)
                
                col1, col2 = st.columns(2)
                
                with col1:
                    if st.button("🚀 Start Email Campaign", type="primary"):
                        if not subject_template or not body_template:
                            st.error("Please provide both subject and body templates")
                        else:
                            with st.spinner("Generating and sending emails..."):
                                if email_timing == "Send in batches":
                                    # Batch sending logic
                                    total_sent = 0
                                    total_failed = 0
                                    total_primary = 0
                                    total_spam_likely = 0
                                    
                                    batches = [st.session_state.results_df[i:i+batch_size] 
                                            for i in range(0, len(st.session_state.results_df), batch_size)]
                                    
                                    for batch_num, batch_df in enumerate(batches, 1):
                                        st.info(f"Processing batch {batch_num}/{len(batches)}")
                                        
                                        sent, failed, primary, spam_likely = send_bulk_emails_with_ai_enhanced(
                                            batch_df, subject_template, body_template, column_name, use_ai_generation
                                        )
                                        
                                        total_sent += sent
                                        total_failed += failed
                                        total_primary += primary
                                        total_spam_likely += spam_likely
                                        
                                        if batch_num < len(batches):
                                            st.info(f"Waiting {batch_delay} minutes before next batch...")
                                            time.sleep(batch_delay * 60)
                                    
                                    st.success(f"Campaign completed! Total: {total_sent} sent, {total_failed} failed")
                                else:
                                    send_bulk_emails_with_ai_enhanced(
                                        st.session_state.results_df, 
                                        subject_template, 
                                        body_template, 
                                        column_name, 
                                        use_ai_generation
                                    )
                                    
                with col2:
                    if email_timing == "Schedule for later":
                        schedule_time = st.text_input("Schedule time (HH:MM format, e.g., 14:30):")
                        if st.button("⏰ Schedule Campaign"):
                            if not schedule_time:
                                st.error("Please provide a schedule time")
                            elif not subject_template or not body_template:
                                st.error("Please provide both subject and body templates")
                            else:
                                try:
                                    # Validate time format
                                    time.strptime(schedule_time, '%H:%M')
                                    
                                    def scheduled_job():
                                        send_bulk_emails_with_ai_enhanced(
                                            st.session_state.results_df, 
                                            subject_template, 
                                            body_template, 
                                            column_name, 
                                            use_ai_generation
                                        )
                                    
                                    thread = threading.Thread(target=scheduled_job)
                                    thread.daemon = True
                                    thread.start()
                                    st.success(f"Campaign scheduled for {schedule_time} daily")
                                except ValueError:
                                    st.error("Invalid time format. Use HH:MM (e.g., 14:30)")

                # Preview AI-generated content
                if use_ai_generation and st.button("👀 Preview AI-Generated Content"):
                    if subject_template and body_template and not st.session_state.results_df.empty:
                        with st.spinner("Generating preview..."):
                            # Use first company for preview
                            first_row = st.session_state.results_df.iloc[0]
                            company_name = str(first_row.get(column_name, 'Sample Company'))
                            extracted_info = str(first_row.get('Extracted Information', ''))
                            
                            # Generate preview content
                            company_info = f"Company: {company_name}\nExtracted Information: {extracted_info}"
                            preview_subject = generate_email_subject(subject_template, company_name, company_info, GROQ_API_KEY)
                            preview_body = generate_email_content(body_template, company_name, company_info, extracted_info, GROQ_API_KEY)
                            
                            st.subheader(f"Preview for: {company_name}")
                            
                            col1, col2 = st.columns(2)
                            with col1:
                                st.text_area("Generated Subject:", preview_subject, disabled=True, height=100)
                            with col2:
                                # Check deliverability
                                email = first_row.get('Gmail', '')
                                if is_valid_email(email):
                                    score, warnings = validate_email_deliverability(email)
                                    st.metric("Deliverability Score", f"{score}%")
                                    if warnings:
                                        st.warning("Warnings: " + ", ".join(warnings))
                            
                            st.text_area("Generated Body:", preview_body, height=200, disabled=True)
                            
                            # Show HTML preview
                            with st.expander("📧 HTML Email Preview"):
                                html_preview = create_html_email_body(preview_body, company_name)
                                st.components.v1.html(html_preview, height=600, scrolling=True)
                    else:
                        st.error("Please provide templates and ensure data is loaded")

                # Test email functionality
                st.subheader("🧪 Test Email")
                col1, col2 = st.columns(2)
                
                with col1:
                    test_email = st.text_input("Enter test email address:")
                
                with col2:
                    if is_valid_email(test_email):
                        score, warnings = validate_email_deliverability(test_email)
                        st.metric("Test Email Score", f"{score}%")
                        if warnings:
                            st.caption("⚠️ " + ", ".join(warnings))
                
                if st.button("📧 Send Test Email"):
                    if test_email and subject_template and body_template:
                        with st.spinner("Generating and sending test email..."):
                            if use_ai_generation:
                                test_subject = generate_email_subject(subject_template, "Test Company", "Company: Test Company\nExtracted Information: Sample business for testing", GROQ_API_KEY)
                                test_body = generate_email_content(body_template, "Test Company", "Company: Test Company\nExtracted Information: Sample business for testing", "Sample business for testing", GROQ_API_KEY)
                            else:
                                test_subject = subject_template.replace("{company_name}", "Test Company")
                                test_body = body_template.replace("{company_name}", "Test Company")
                            
                            success, message, email_id = send_email_enhanced(test_email, test_subject, test_body, "Test Company")
                            if success:
                                st.success(message)
                                with st.expander("📧 Test Email Content"):
                                    st.text_area("Test Subject Sent:", test_subject, disabled=True)
                                    st.text_area("Test Body Sent:", test_body, height=150, disabled=True)
                            else:
                                st.error(message)
                    else:
                        st.error("Please provide test email, subject template, and body template")

elif page == "Dashboard":
    create_email_dashboard()

elif page == "Settings":
    st.header("⚙️ Email System Settings")
    
    st.subheader("📧 Email Configuration")
    st.info("Configure your email settings in the .env file:")
    
    st.code("""
# Add these to your .env file:
EMAIL=your-sender-email@domain.com
MAILJET_API_KEY=your-mailjet-api-key
MAILJET_SECRET_KEY=your-mailjet-secret-key
SERP_API_KEY=your-serpapi-key
GROQ_API_KEY=your-groq-api-key
    """)
    
    st.subheader("🎯 Deliverability Tips")
    st.markdown("""
    ### To improve email deliverability and avoid spam:
    
    **1. Email Authentication**
    - Set up SPF, DKIM, and DMARC records for your domain
    - Use a business email address, not personal Gmail
    
    **2. Content Best Practices**
    - Avoid spam trigger words (FREE, URGENT, GUARANTEED)
    - Keep subject lines under 50 characters
    - Use proper HTML formatting
    - Include an unsubscribe link
    
    **3. Sending Behavior**
    - Start with small batches to build reputation
    - Use consistent sending patterns
    - Monitor bounce rates and engagement
    
    **4. List Quality**
    - Use only valid, opted-in email addresses
    - Regularly clean your email list
    - Avoid purchased email lists
    
    **5. Technical Setup**
    - Use dedicated IP address for high volume
    - Monitor sender reputation
    - Set up feedback loops with ISPs
    """)
    
    st.subheader("📊 Database Management")
    col1, col2 = st.columns(2)
    
    with col1:
        if st.button("🗑️ Clear Email Logs"):
            conn = sqlite3.connect("email_tracking.db")
            cursor = conn.cursor()
            cursor.execute("DELETE FROM email_logs")
            conn.commit()
            conn.close()
            st.success("Email logs cleared successfully!")
    
    with col2:
        if st.button("📋 Export All Data"):
            email_stats = get_email_stats()
            if not email_stats.empty:
                csv = email_stats.to_csv(index=False)
                st.download_button(
                    label="💾 Download Complete Database",
                    data=csv,
                    file_name=f"complete_email_data_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
                    mime="text/csv"
                )
            else:
                st.warning("No data to export")

# Footer
st.markdown("---")
st.markdown("🚀 **AutoMail : An Enhanced Email System** - Powered by AI for better deliverability and tracking")